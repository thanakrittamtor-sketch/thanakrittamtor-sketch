import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

/**
 * ตัวอย่างหน้าตาโชว์ผลงาน (Portfolio) ด้วย JavaFX
 * รันด้วยคำสั่ง:
 *   javac PortfolioApp.java
 *   java --module-path <path-to-javafx-lib> --add-modules javafx.controls PortfolioApp
 * (ถ้าใช้ JDK ที่รวม JavaFX มาแล้ว หรือใช้ IDE เช่น IntelliJ/Eclipse ที่ตั้งค่า JavaFX ไว้แล้ว
 *  ก็สามารถรันตรง ๆ ได้เลย)
 */
public class PortfolioApp extends Application {

    // โครงสร้างข้อมูลผลงาน 1 ชิ้น
    static class Project {
        String title;
        String description;
        String link;

        Project(String title, String description, String link) {
            this.title = title;
            this.description = description;
            this.link = link;
        }
    }

    @Override
    public void start(Stage stage) {
        // ----- ส่วนหัว (Header / Profile) -----
        VBox header = new VBox(8);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(30, 20, 20, 20));
        header.getStyleClass().add("header");

        Text name = new Text("ชื่อ - นามสกุล");
        name.getStyleClass().add("name-text");

        Text role = new Text("Full-Stack Developer");
        role.getStyleClass().add("role-text");

        Text bio = new Text("รวมผลงานและโปรเจกต์ที่เคยพัฒนา พร้อมรายละเอียดและลิงก์เพิ่มเติม");
        bio.getStyleClass().add("bio-text");
        bio.setWrappingWidth(500);
        bio.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        header.getChildren().addAll(name, role, bio);

        // ----- ข้อมูลผลงานตัวอย่าง (ปรับแก้/เพิ่มเองได้) -----
        List<Project> projects = new ArrayList<>();
        projects.add(new Project("ระบบจัดการร้านค้าออนไลน์",
                "เว็บแอปสำหรับจัดการสินค้า คำสั่งซื้อ และสต็อกสินค้า พัฒนาด้วย Spring Boot + React",
                "https://github.com/yourname/shop-system"));
        projects.add(new Project("แอปติดตามงบประมาณส่วนตัว",
                "แอปมือถือช่วยบันทึกรายรับ-รายจ่าย พร้อมกราฟสรุปรายเดือน",
                "https://github.com/yourname/budget-app"));
        projects.add(new Project("ระบบจองคิวออนไลน์",
                "ระบบจองคิวสำหรับคลินิก รองรับการแจ้งเตือนผ่าน LINE Notify",
                "https://github.com/yourname/queue-booking"));

        // ----- การ์ดผลงาน -----
        FlowPane cardContainer = new FlowPane();
        cardContainer.setHgap(20);
        cardContainer.setVgap(20);
        cardContainer.setPadding(new Insets(20));
        cardContainer.setAlignment(Pos.CENTER);

        for (Project p : projects) {
            cardContainer.getChildren().add(createProjectCard(p));
        }

        ScrollPane scrollPane = new ScrollPane(cardContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("scroll-area");

        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(scrollPane);

        Scene scene = new Scene(root, 900, 650);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        stage.setTitle("My Portfolio");
        stage.setScene(scene);
        stage.show();
    }

    private VBox createProjectCard(Project project) {
        VBox card = new VBox(10);
        card.getStyleClass().add("project-card");
        card.setPrefWidth(260);
        card.setPadding(new Insets(15));

        // กรอบรูปภาพ (ใส่รูปจริงภายหลังได้ด้วย new Image("file:..." หรือ URL)
        Region imagePlaceholder = new Region();
        imagePlaceholder.getStyleClass().add("image-placeholder");
        imagePlaceholder.setPrefHeight(140);

        Text title = new Text(project.title);
        title.getStyleClass().add("card-title");
        title.setWrappingWidth(230);

        Text desc = new Text(project.description);
        desc.getStyleClass().add("card-desc");
        desc.setWrappingWidth(230);

        Hyperlink link = new Hyperlink("ดูรายละเอียด →");
        link.getStyleClass().add("card-link");
        link.setOnAction(e -> getHostServices().showDocument(project.link));

        card.getChildren().addAll(imagePlaceholder, title, desc, link);
        return card;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
